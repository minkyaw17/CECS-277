/**
 * Creating a class Classes that have
 * pre-determined courses
 */
public class Classes {
    public static final String SCIENCE = "BIOL 200";
    public static final String MATH = "MATH 123";
    public static final String COMPUTERSCIENCE = "CECS 277";
    public static final String ENGLISH = "ENGL 300";
    public static final String ART = "ART 103";
    public static final String HISTORY = "HIST 173";
}
