public class Main {
    public static void main(String[] args) {
        VendingMachine VM = new VendingMachine();
        VendingMachineInputMenu VMenu = new VendingMachineInputMenu();

        VMenu.program(VM); // running the program

    }
}
