import java.util.Comparator;

import java.util.*;

// method for E.
public class LNameComparator implements Comparator{
    public int compare(Object l1, Object l2) {
        Employee e1 = (Employee) l1;
        Employee e2 = (Employee) l2;
        return e2.getLastName().compareTo(e1.getLastName());
    }
}

// public class FacultyClone extends Employee implements Cloneable {
//    public enum Level {
//        AS,
//        AO,
//        FU
//    }
//
//
//    private Faculty.Level level;
//    private Education.Degree edu;
//
//    public FacultyClone() {
//        super();
//    }
//
//    public FacultyClone(Faculty.Level lvl, Education.Degree Edu) {
//        this.level = lvl;
//        this.edu = Edu;
//    }
//
//    public void setLevel(Faculty.Level lvl){
//        this.level = lvl;
//    }
//
//    public Faculty.Level getLevel() {
//        return level;
//    }
//
//    public void setEdu(Education.Degree edu) {
//        this.edu = edu;
//    }
//
//    public Education.Degree getEdu() {
//        return edu;
//    }
//
//    @SuppressWarnings("null")
//    @Override
//    public double monthlyEarning() {
//        switch (level) {
//            case AS:
//                return FACULTY_MONTHLY_SALARY;
//            case AO:
//                return FACULTY_MONTHLY_SALARY * 1.5;
//            case FU:
//                return FACULTY_MONTHLY_SALARY * 2.0;
//        }
//        return 0;
//    }
//
//    String professor;
//
//    public String toString() {
//        String Fname = this.getFirstName();
//        String Lname = this.getLastName();
//        String ID = this.getIDNumber();
//        char Sex = this.getSex();
//        Date D = this.getBirthDate();
//
//        switch (level) {
//            case AS:
//                professor = "Assistant Professor";
//                break;
//            case AO:
//                professor = "Associate Professor";
//                break;
//            case FU:
//                professor = "Full Time Professor";
//                break;
//        }
//        return "Last Name: " + Lname + "\nFirst Name: " + Fname +
//                "\nID: " + ID +
//                "\nSex: " + Sex +
//                "\nBirth Date: " + D +
//                "\nLevel: " + professor +
//                "\nFull Time Monthly Salary: $" + this.monthlyEarning();
//    }
//
//    Faculty FClone = new Faculty();
//    public Object clone() throws CloneNotSupportedException {
//        FacultyClone FC = (FacultyClone) super.clone();
//        FC.FClone = new Faculty();
//        return FC;
//    }
//}